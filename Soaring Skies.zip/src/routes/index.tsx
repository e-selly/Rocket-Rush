import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Rocket Rush — Tap. Dodge. Soar." },
      { name: "description", content: "A one-tap arcade flyer through neon asteroid rings. Simple, addictive, endless." },
      { property: "og:title", content: "Rocket Rush" },
      { property: "og:description", content: "Tap to thrust. Dodge neon rings. How far can you fly?" },
    ],
  }),
  component: Game,
});

type Ring = { x: number; gapY: number; gapH: number; passed: boolean; hue: number; hasCoin: boolean; coinTaken: boolean };
type Particle = { x: number; y: number; vx: number; vy: number; life: number; hue: number };

const W = 420;
const H = 720;
const GRAVITY = 0.42;
const THRUST = -7.4;
const RING_W = 62;

// ---------- Skins ----------
type Skin = {
  id: string;
  name: string;
  cost: number;
  body: string;
  window: string;
  fin: string;
  flameHue: number;
  trailHue: number;
};

const SKINS: Skin[] = [
  { id: "classic", name: "Classic", cost: 0, body: "#e8f0ff", window: "#4dd6ff", fin: "#ff3d7f", flameHue: 25, trailHue: 25 },
  { id: "emerald", name: "Emerald", cost: 25, body: "#a7ffcb", window: "#0fffb3", fin: "#00764a", flameHue: 140, trailHue: 140 },
  { id: "sunset", name: "Sunset", cost: 60, body: "#ffd6a5", window: "#ff8b3d", fin: "#c92a5b", flameHue: 15, trailHue: 340 },
  { id: "void", name: "Void", cost: 120, body: "#2a2140", window: "#c98bff", fin: "#7a2dff", flameHue: 280, trailHue: 280 },
  { id: "gold", name: "Gold", cost: 250, body: "#ffe066", window: "#fff8b8", fin: "#b8860b", flameHue: 45, trailHue: 45 },
  { id: "rainbow", name: "Prism", cost: 500, body: "#ffffff", window: "#ffffff", fin: "#ffffff", flameHue: -1, trailHue: -1 },
];

// ---------- Audio ----------
let audioCtx: AudioContext | null = null;
let muted = false;
function getCtx() {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    try {
      audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch {
      return null;
    }
  }
  return audioCtx;
}
function beep(freq: number, dur = 0.08, type: OscillatorType = "square", vol = 0.08) {
  if (muted) return;
  const ctx = getCtx();
  if (!ctx) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, ctx.currentTime);
  g.gain.setValueAtTime(vol, ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
  o.connect(g).connect(ctx.destination);
  o.start();
  o.stop(ctx.currentTime + dur);
}
function sfxFlap() { beep(520, 0.06, "square", 0.05); }
function sfxScore() { beep(880, 0.06, "triangle", 0.07); setTimeout(() => beep(1320, 0.08, "triangle", 0.06), 40); }
function sfxCoin() { beep(1200, 0.05, "sine", 0.08); setTimeout(() => beep(1800, 0.09, "sine", 0.07), 30); }
function sfxDie() {
  beep(200, 0.12, "sawtooth", 0.09);
  setTimeout(() => beep(120, 0.18, "sawtooth", 0.08), 80);
  setTimeout(() => beep(70, 0.25, "sawtooth", 0.07), 200);
}
function vibrate(pattern: number | number[]) {
  if (typeof navigator !== "undefined" && "vibrate" in navigator) {
    try { navigator.vibrate(pattern); } catch { /* noop */ }
  }
}

// ---------- Daily Challenge ----------
function dayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function seededRandom(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
}
function hashString(str: string) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef({
    y: H / 2,
    vy: 0,
    rings: [] as Ring[],
    coins: [] as { x: number; y: number; taken: boolean; wobble: number }[],
    tick: 0,
    dead: false,
    started: false,
    score: 0,
    coinsCollected: 0,
    particles: [] as Particle[],
    stars: [] as { x: number; y: number; z: number }[],
    shake: 0,
    rand: Math.random,
    dailyMode: false,
    continued: false,
  });
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [coins, setCoins] = useState(0);
  const [totalCoins, setTotalCoins] = useState(0);
  const [status, setStatus] = useState<"idle" | "playing" | "dead" | "shop" | "adPlaying">("idle");
  const [equippedSkinId, setEquippedSkinId] = useState<string>("classic");
  const [ownedSkins, setOwnedSkins] = useState<string[]>(["classic"]);
  const [soundOn, setSoundOn] = useState(true);
  const [dailyMode, setDailyMode] = useState(false);
  const [dailyBest, setDailyBest] = useState(0);
  const [dailyCompletedDate, setDailyCompletedDate] = useState<string | null>(null);
  const [adCountdown, setAdCountdown] = useState(0);
  const [shareToast, setShareToast] = useState("");

  const equippedSkin = SKINS.find((s) => s.id === equippedSkinId) || SKINS[0];

  useEffect(() => {
    setBest(Number(localStorage.getItem("rocket-rush-best") || 0));
    setTotalCoins(Number(localStorage.getItem("rocket-rush-coins") || 0));
    setEquippedSkinId(localStorage.getItem("rocket-rush-skin") || "classic");
    try {
      setOwnedSkins(JSON.parse(localStorage.getItem("rocket-rush-owned") || '["classic"]'));
    } catch { setOwnedSkins(["classic"]); }
    const mutedStored = localStorage.getItem("rocket-rush-muted") === "1";
    setSoundOn(!mutedStored);
    muted = mutedStored;
    const dk = dayKey();
    setDailyBest(Number(localStorage.getItem(`rocket-rush-daily-${dk}`) || 0));
    setDailyCompletedDate(localStorage.getItem("rocket-rush-daily-done"));

    const s = stateRef.current;
    s.stars = Array.from({ length: 80 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      z: Math.random() * 0.8 + 0.2,
    }));
  }, []);

  const toggleSound = useCallback(() => {
    setSoundOn((v) => {
      const nv = !v;
      muted = !nv;
      localStorage.setItem("rocket-rush-muted", muted ? "1" : "0");
      return nv;
    });
  }, []);

  const reset = useCallback((daily = false) => {
    const s = stateRef.current;
    s.y = H / 2;
    s.vy = 0;
    s.rings = [];
    s.coins = [];
    s.tick = 0;
    s.dead = false;
    s.started = false;
    s.score = 0;
    s.coinsCollected = 0;
    s.particles = [];
    s.shake = 0;
    s.continued = false;
    s.dailyMode = daily;
    s.rand = daily ? seededRandom(hashString(dayKey())) : Math.random;
    setScore(0);
    setCoins(0);
    setStatus("idle");
  }, []);

  const flap = useCallback(() => {
    const s = stateRef.current;
    if (s.dead) return; // dead-state handled by explicit buttons now
    if (!s.started) {
      s.started = true;
      setStatus("playing");
      getCtx()?.resume?.();
    }
    s.vy = THRUST;
    sfxFlap();
    vibrate(8);
    for (let i = 0; i < 8; i++) {
      s.particles.push({
        x: W / 3 - 10,
        y: s.y + 10,
        vx: -Math.random() * 3 - 1,
        vy: Math.random() * 2 - 1,
        life: 1,
        hue: equippedSkin.trailHue < 0 ? Math.random() * 360 : equippedSkin.trailHue + (Math.random() * 30 - 15),
      });
    }
  }, [equippedSkin]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space" || e.code === "ArrowUp") {
        e.preventDefault();
        if (status === "playing" || status === "idle") flap();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [flap, status]);

  const dieRef = useRef<() => void>(() => {});

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    let raf = 0;

    const spawnRing = () => {
      const s = stateRef.current;
      const gapH = Math.max(150, 210 - s.score * 2);
      const gapY = 80 + s.rand() * (H - 160 - gapH);
      const hasCoin = s.rand() > 0.55;
      s.rings.push({
        x: W + 40,
        gapY,
        gapH,
        passed: false,
        hue: (s.tick * 0.5) % 360,
        hasCoin,
        coinTaken: false,
      });
    };

    const die = () => {
      const s = stateRef.current;
      if (s.dead) return;
      s.dead = true;
      s.shake = 16;
      sfxDie();
      vibrate([30, 40, 60]);
      for (let i = 0; i < 40; i++) {
        s.particles.push({
          x: W / 3,
          y: s.y,
          vx: (Math.random() - 0.5) * 8,
          vy: (Math.random() - 0.5) * 8,
          life: 1,
          hue: Math.random() * 60,
        });
      }
      setStatus("dead");

      // Save coins
      const newTotal = Number(localStorage.getItem("rocket-rush-coins") || 0) + s.coinsCollected;
      localStorage.setItem("rocket-rush-coins", String(newTotal));
      setTotalCoins(newTotal);

      if (s.dailyMode) {
        const dk = dayKey();
        const prev = Number(localStorage.getItem(`rocket-rush-daily-${dk}`) || 0);
        const nb = Math.max(prev, s.score);
        localStorage.setItem(`rocket-rush-daily-${dk}`, String(nb));
        localStorage.setItem("rocket-rush-daily-done", dk);
        setDailyBest(nb);
        setDailyCompletedDate(dk);
      } else {
        setBest((b) => {
          const nb = Math.max(b, s.score);
          localStorage.setItem("rocket-rush-best", String(nb));
          return nb;
        });
      }
    };
    dieRef.current = die;

    const loop = () => {
      const s = stateRef.current;
      s.tick++;

      const grad = ctx.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, "#0a0420");
      grad.addColorStop(0.5, "#1a0836");
      grad.addColorStop(1, "#2a0a4a");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);

      ctx.save();
      if (s.shake > 0) {
        ctx.translate((Math.random() - 0.5) * s.shake, (Math.random() - 0.5) * s.shake);
        s.shake *= 0.85;
      }

      for (const st of s.stars) {
        if (s.started && !s.dead) st.x -= st.z * 1.5;
        if (st.x < 0) st.x += W;
        ctx.fillStyle = `rgba(255,255,255,${st.z})`;
        ctx.fillRect(st.x, st.y, st.z * 2, st.z * 2);
      }

      if (s.started && !s.dead) {
        s.vy += GRAVITY;
        s.y += s.vy;
        if (s.tick % 90 === 0) spawnRing();
        for (const r of s.rings) r.x -= 3.2;
        s.rings = s.rings.filter((r) => r.x > -80);
      }

      // rings
      for (const r of s.rings) {
        const hue = r.hue;
        ctx.fillStyle = `hsl(${hue}, 90%, 55%)`;
        ctx.shadowColor = `hsl(${hue}, 100%, 60%)`;
        ctx.shadowBlur = 20;
        ctx.fillRect(r.x, 0, RING_W, r.gapY);
        ctx.fillRect(r.x, r.gapY + r.gapH, RING_W, H - r.gapY - r.gapH);
        ctx.fillStyle = `hsl(${(hue + 40) % 360}, 100%, 70%)`;
        ctx.fillRect(r.x - 4, r.gapY - 12, RING_W + 8, 12);
        ctx.fillRect(r.x - 4, r.gapY + r.gapH, RING_W + 8, 12);
        ctx.shadowBlur = 0;

        // coin
        if (r.hasCoin && !r.coinTaken) {
          const cx = r.x + RING_W / 2;
          const cy = r.gapY + r.gapH / 2 + Math.sin(s.tick * 0.1 + r.x) * 4;
          ctx.fillStyle = "#ffd700";
          ctx.shadowColor = "#ffaa00";
          ctx.shadowBlur = 15;
          ctx.beginPath();
          ctx.arc(cx, cy, 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#fff8b0";
          ctx.beginPath();
          ctx.arc(cx - 2, cy - 2, 3, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      }

      // rocket
      const px = W / 3;
      const py = s.y;
      const angle = Math.max(-0.5, Math.min(1.2, s.vy * 0.08));
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(angle);
      if (s.started && !s.dead) {
        const fl = 12 + Math.random() * 8;
        const fh = equippedSkin.flameHue < 0 ? Math.random() * 360 : equippedSkin.flameHue + Math.random() * 30;
        ctx.fillStyle = `hsl(${fh}, 100%, 60%)`;
        ctx.shadowColor = `hsl(${fh}, 100%, 60%)`;
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.moveTo(-18, -6);
        ctx.lineTo(-18 - fl, 0);
        ctx.lineTo(-18, 6);
        ctx.closePath();
        ctx.fill();
        ctx.shadowBlur = 0;
      }
      // body
      if (equippedSkin.id === "rainbow") {
        const g = ctx.createLinearGradient(-18, 0, 20, 0);
        g.addColorStop(0, "#ff3d7f");
        g.addColorStop(0.5, "#ffe066");
        g.addColorStop(1, "#4dd6ff");
        ctx.fillStyle = g;
      } else {
        ctx.fillStyle = equippedSkin.body;
      }
      ctx.beginPath();
      ctx.moveTo(20, 0);
      ctx.lineTo(-10, -12);
      ctx.lineTo(-18, -8);
      ctx.lineTo(-18, 8);
      ctx.lineTo(-10, 12);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = equippedSkin.window;
      ctx.beginPath();
      ctx.arc(4, 0, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = equippedSkin.fin;
      ctx.beginPath();
      ctx.moveTo(-10, -12);
      ctx.lineTo(-18, -18);
      ctx.lineTo(-18, -8);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-10, 12);
      ctx.lineTo(-18, 18);
      ctx.lineTo(-18, 8);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      for (const p of s.particles) {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.03;
        ctx.fillStyle = `hsla(${p.hue}, 100%, 60%, ${p.life})`;
        ctx.fillRect(p.x, p.y, 3, 3);
      }
      s.particles = s.particles.filter((p) => p.life > 0);

      if (s.started && !s.dead) {
        if (s.y < 10 || s.y > H - 10) die();
        for (const r of s.rings) {
          if (px + 18 > r.x && px - 18 < r.x + RING_W) {
            if (s.y - 10 < r.gapY || s.y + 10 > r.gapY + r.gapH) die();
          }
          if (!r.passed && r.x + RING_W < px) {
            r.passed = true;
            s.score++;
            setScore(s.score);
            sfxScore();
            vibrate(5);
          }
          // coin collect
          if (r.hasCoin && !r.coinTaken) {
            const cx = r.x + RING_W / 2;
            const cy = r.gapY + r.gapH / 2;
            const dx = cx - px;
            const dy = cy - s.y;
            if (dx * dx + dy * dy < 22 * 22) {
              r.coinTaken = true;
              s.coinsCollected++;
              setCoins(s.coinsCollected);
              sfxCoin();
              vibrate(12);
              for (let i = 0; i < 12; i++) {
                s.particles.push({
                  x: cx,
                  y: cy,
                  vx: (Math.random() - 0.5) * 4,
                  vy: (Math.random() - 0.5) * 4,
                  life: 1,
                  hue: 50,
                });
              }
            }
          }
        }
      }

      ctx.restore();
      ctx.fillStyle = "rgba(255,255,255,0.95)";
      ctx.font = "bold 56px system-ui, -apple-system, sans-serif";
      ctx.textAlign = "center";
      ctx.shadowColor = "rgba(255, 61, 127, 0.8)";
      ctx.shadowBlur = 20;
      ctx.fillText(String(s.score), W / 2, 90);
      ctx.shadowBlur = 0;

      // coin HUD
      if (s.started || s.dead) {
        ctx.fillStyle = "#ffd700";
        ctx.beginPath();
        ctx.arc(24, 130, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.font = "bold 16px system-ui, sans-serif";
        ctx.textAlign = "left";
        ctx.fillText(`×${s.coinsCollected}`, 38, 135);
      }

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [equippedSkin]);

  // ---------- Continue via Rewarded Ad ----------
  const continueRun = useCallback(() => {
    setStatus("adPlaying");
    setAdCountdown(3);
    const iv = setInterval(() => {
      setAdCountdown((c) => {
        if (c <= 1) {
          clearInterval(iv);
          // resume
          const s = stateRef.current;
          s.dead = false;
          s.continued = true;
          s.y = H / 2;
          s.vy = 0;
          s.shake = 0;
          // clear nearby rings so player has breathing room
          s.rings = s.rings.filter((r) => r.x > W / 2 + 80);
          setStatus("playing");
          return 0;
        }
        return c - 1;
      });
    }, 1000);
  }, []);

  // ---------- Share ----------
  const share = useCallback(async () => {
    const label = stateRef.current.dailyMode ? "Daily Challenge" : "Rocket Rush";
    const text = `🚀 I scored ${score} in ${label}! Beat me: ${typeof window !== "undefined" ? window.location.origin : ""}`;
    try {
      if (typeof navigator !== "undefined" && (navigator as any).share) {
        await (navigator as any).share({ title: "Rocket Rush", text });
        return;
      }
    } catch { /* user cancelled */ }
    try {
      await navigator.clipboard.writeText(text);
      setShareToast("Copied to clipboard!");
      setTimeout(() => setShareToast(""), 1800);
    } catch {
      setShareToast("Could not share");
      setTimeout(() => setShareToast(""), 1800);
    }
  }, [score]);

  // ---------- Shop ----------
  const buySkin = useCallback((id: string) => {
    const skin = SKINS.find((s) => s.id === id);
    if (!skin) return;
    if (ownedSkins.includes(id)) {
      setEquippedSkinId(id);
      localStorage.setItem("rocket-rush-skin", id);
      return;
    }
    if (totalCoins < skin.cost) return;
    const newTotal = totalCoins - skin.cost;
    const newOwned = [...ownedSkins, id];
    setTotalCoins(newTotal);
    setOwnedSkins(newOwned);
    setEquippedSkinId(id);
    localStorage.setItem("rocket-rush-coins", String(newTotal));
    localStorage.setItem("rocket-rush-owned", JSON.stringify(newOwned));
    localStorage.setItem("rocket-rush-skin", id);
    sfxCoin();
  }, [ownedSkins, totalCoins]);

  const startDaily = useCallback(() => {
    setDailyMode(true);
    reset(true);
  }, [reset]);

  const startNormal = useCallback(() => {
    setDailyMode(false);
    reset(false);
  }, [reset]);

  const dailyDoneToday = dailyCompletedDate === dayKey();

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-[#05010f] text-white overflow-hidden select-none py-4">
      <div className="mb-3 text-center">
        <h1 className="text-2xl font-black tracking-tight bg-gradient-to-r from-pink-400 via-fuchsia-400 to-cyan-300 bg-clip-text text-transparent">
          ROCKET RUSH
        </h1>
        <div className="flex items-center justify-center gap-3 text-xs text-white/60 mt-1">
          <span>Best: {best}</span>
          <span className="text-yellow-400">● {totalCoins}</span>
          {dailyMode && <span className="text-cyan-300">Daily</span>}
        </div>
      </div>
      <div
        className="relative rounded-2xl overflow-hidden shadow-[0_0_60px_rgba(255,61,127,0.35)] border border-white/10 touch-none"
        style={{ width: W, height: H, maxWidth: "100vw", maxHeight: "78vh" }}
        onPointerDown={(e) => {
          // Ignore taps on overlay UI (buttons, shop, menus)
          const target = e.target as HTMLElement;
          if (target.closest("button") || target.closest("[data-ui-overlay]")) return;
          if (status === "playing" || status === "idle") {
            e.preventDefault();
            flap();
          }
        }}
      >
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          style={{ width: "100%", height: "100%", display: "block" }}
        />

        {/* Top-right controls */}
        <div className="absolute top-2 right-2 flex gap-2 pointer-events-auto">
          <button
            onClick={toggleSound}
            className="w-9 h-9 rounded-full bg-black/50 backdrop-blur border border-white/10 text-sm hover:bg-black/70 transition"
            aria-label="Toggle sound"
          >
            {soundOn ? "🔊" : "🔇"}
          </button>
        </div>

        {status === "idle" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 backdrop-blur-sm">
            <div className="text-center animate-fade-in pointer-events-none">
              <div className="text-5xl mb-3">🚀</div>
              <p className="text-xl font-bold">Tap to thrust</p>
              <p className="text-sm text-white/60 mt-1">
                {dailyMode ? "Same seed for everyone today" : "Dodge the neon rings"}
              </p>
              <p className="text-xs text-white/40 mt-4">Space / Tap</p>
            </div>
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 px-4 pointer-events-auto">
              <button
                onClick={(e) => { e.stopPropagation(); setStatus("shop"); }}
                className="px-4 py-2 rounded-full bg-white/10 backdrop-blur border border-white/20 text-xs font-semibold hover:bg-white/20 transition"
              >
                🎨 Skins
              </button>
              {!dailyMode ? (
                <button
                  onClick={(e) => { e.stopPropagation(); startDaily(); }}
                  disabled={dailyDoneToday}
                  className="px-4 py-2 rounded-full bg-cyan-500/20 backdrop-blur border border-cyan-400/30 text-xs font-semibold hover:bg-cyan-500/30 transition disabled:opacity-50"
                >
                  {dailyDoneToday ? `✓ Daily ${dailyBest}` : "⭐ Daily Challenge"}
                </button>
              ) : (
                <button
                  onClick={(e) => { e.stopPropagation(); startNormal(); }}
                  className="px-4 py-2 rounded-full bg-white/10 backdrop-blur border border-white/20 text-xs font-semibold hover:bg-white/20 transition"
                >
                  ← Endless
                </button>
              )}
            </div>
          </div>
        )}

        {status === "dead" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm px-6">
            <div className="text-center animate-scale-in">
              <p className="text-sm text-white/60 uppercase tracking-widest">
                {stateRef.current.dailyMode ? "Daily done" : "Crashed"}
              </p>
              <p className="text-6xl font-black my-2 bg-gradient-to-r from-pink-400 to-cyan-300 bg-clip-text text-transparent">
                {score}
              </p>
              <p className="text-sm text-white/60">
                {stateRef.current.dailyMode ? `Daily best ${dailyBest}` : `Best ${best}`}
                <span className="text-yellow-400 ml-3">+{coins} ●</span>
              </p>
            </div>
            <div className="mt-6 flex flex-col gap-2 w-full max-w-[280px]">
              {!stateRef.current.continued && !stateRef.current.dailyMode && (
                <button
                  onClick={continueRun}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 font-bold text-sm shadow-lg hover:brightness-110 transition flex items-center justify-center gap-2"
                >
                  ▶ Continue (Watch Ad)
                </button>
              )}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => reset(stateRef.current.dailyMode)}
                  className="py-2.5 rounded-xl bg-white/10 border border-white/20 font-semibold text-sm hover:bg-white/20 transition"
                >
                  ↻ Retry
                </button>
                <button
                  onClick={share}
                  className="py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-fuchsia-500 font-semibold text-sm hover:brightness-110 transition"
                >
                  ↗ Share
                </button>
              </div>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => setStatus("shop")}
                  className="py-2 px-3 text-xs text-white/60 hover:text-white transition"
                >
                  🎨 Skins
                </button>
                <button
                  onClick={() => { setDailyMode(false); reset(false); }}
                  className="py-2 px-3 text-xs text-white/50 hover:text-white/80 transition"
                >
                  Back to menu
                </button>
              </div>
            </div>
          </div>
        )}

        {status === "adPlaying" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 backdrop-blur-sm">
            <p className="text-xs text-white/40 uppercase tracking-widest mb-4">Sponsored</p>
            <div className="w-48 h-48 rounded-2xl bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 flex items-center justify-center text-5xl animate-pulse">
              🎁
            </div>
            <p className="mt-6 text-lg font-bold">Reward in {adCountdown}s</p>
            <p className="text-xs text-white/40 mt-2">(Demo — real ads via AdMob after publish)</p>
          </div>
        )}

        {status === "shop" && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold">Skins</h2>
              <div className="flex items-center gap-2">
                <span className="text-yellow-400 text-sm font-bold">● {totalCoins}</span>
                <button
                  onClick={() => setStatus("idle")}
                  className="w-8 h-8 rounded-full bg-white/10 border border-white/20 text-sm hover:bg-white/20"
                >
                  ✕
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {SKINS.map((skin) => {
                const owned = ownedSkins.includes(skin.id);
                const equipped = equippedSkinId === skin.id;
                const canBuy = owned || totalCoins >= skin.cost;
                return (
                  <button
                    key={skin.id}
                    onClick={() => buySkin(skin.id)}
                    disabled={!canBuy}
                    className={`relative rounded-xl p-3 border transition text-left ${
                      equipped
                        ? "border-cyan-400 bg-cyan-500/10"
                        : canBuy
                        ? "border-white/15 bg-white/5 hover:bg-white/10"
                        : "border-white/5 bg-white/[0.02] opacity-50"
                    }`}
                  >
                    <div
                      className="w-full h-14 rounded-lg mb-2 flex items-center justify-center"
                      style={{
                        background: skin.id === "rainbow"
                          ? "linear-gradient(90deg,#ff3d7f,#ffe066,#4dd6ff)"
                          : skin.body,
                      }}
                    >
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ background: skin.window }}
                      />
                    </div>
                    <p className="text-sm font-bold">{skin.name}</p>
                    <p className="text-xs mt-0.5">
                      {equipped ? (
                        <span className="text-cyan-300">Equipped</span>
                      ) : owned ? (
                        <span className="text-white/60">Tap to equip</span>
                      ) : (
                        <span className="text-yellow-400">● {skin.cost}</span>
                      )}
                    </p>
                  </button>
                );
              })}
            </div>
            <p className="text-xs text-white/40 text-center mt-4">
              Earn coins by collecting them mid-flight
            </p>
          </div>
        )}

        {shareToast && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/80 border border-white/20 px-4 py-2 rounded-full text-xs animate-fade-in">
            {shareToast}
          </div>
        )}
      </div>
    </div>
  );
}
